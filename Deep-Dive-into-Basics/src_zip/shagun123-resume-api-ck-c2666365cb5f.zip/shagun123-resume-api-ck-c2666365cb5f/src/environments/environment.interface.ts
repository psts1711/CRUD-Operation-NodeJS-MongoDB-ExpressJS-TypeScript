export interface Environment {
    db_url:string,
    production:boolean
}