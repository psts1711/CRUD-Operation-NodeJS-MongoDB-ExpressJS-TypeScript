import {Environment} from "./environment.interface";

export  const environment :Environment =  {
    production : false,
    db_url: 'mongodb+srv://abc:shagaun@cluster0.wlpff.mongodb.net/test?retryWrites=true&w=majority'
};


//mongodb://shagun:GARGSHAGUN15432@ds139939.mlab.com:39939/resume-dev
//
