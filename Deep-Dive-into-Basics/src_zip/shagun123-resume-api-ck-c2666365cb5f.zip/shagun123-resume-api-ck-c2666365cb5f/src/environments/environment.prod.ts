import {Environment} from "./environment.interface";

export const environment: Environment = {
    production: true,
    db_url: 'mongodb://shagun:Shagungarg@15432@ds223685.mlab.com:23685/resume-data'
};