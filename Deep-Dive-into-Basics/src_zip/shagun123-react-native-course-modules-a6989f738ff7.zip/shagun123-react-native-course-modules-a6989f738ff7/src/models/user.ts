export interface User {
  email: string;
  idToken: string;
}
