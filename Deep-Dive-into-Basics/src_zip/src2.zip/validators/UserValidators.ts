import { body } from "express-validator";

export class UserValidator{
    static login(){
        return [body('username', 'Username is required').isString(),
            body('email', 'email is required').isEmail(),
            body('password', 'password is required').custom((req)=>{
                if(req.email)
                {
                    return true;
                }else{
                    throw new Error('Testing Custom Validation')
                }
            })]
    }
}