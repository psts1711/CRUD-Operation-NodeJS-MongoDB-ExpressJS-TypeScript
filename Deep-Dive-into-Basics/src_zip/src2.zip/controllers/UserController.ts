import User from "../models/User";
import { validationResult } from "express-validator";

export class UserController{
    static login(req, res, next)
    {
        // res.send('We are here to login')
        
       // res.send(req.query)         // for param 1st
       // res.send(req.body)          // 2nd
       
      /*  const email = req.body.email;
       const password = req.body.password;
       const user = new User({email: email, password: password});
       user.save().then((user)=>{
           res.send(user)
       }).catch((err)=>{
           next(err)
       }) */

       const error = validationResult(req)
       const username = req.body.username;
       const email = req.body.email;
       const password = req.body.password;

       if(!error.isEmpty())
       {
           const errorMsg  = new Error(error.array()[0].msg)
          next(errorMsg)
       }


    }

   
}