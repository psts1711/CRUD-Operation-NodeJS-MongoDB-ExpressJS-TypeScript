import { Router } from "express";
import { UserController } from "../controllers/UserController";
import {body} from 'express-validator'
import { UserValidator } from "../validators/UserValidators";

 class UserRouter{
    public router: Router;

    constructor() {
        this.router = Router();
        this.getRoutes();
        this.postRoutes();
        this.patchRoutes();
        this.deleteRoute();

    }
    
    getRoutes()
    {
       // this.router.get('/login',UserController.login)
        this.router.post('/login',UserValidator.login(),UserController.login)
    }

    postRoutes()
    {

    }

    patchRoutes()
    {

    }

    deleteRoute()
    {

    }
}

export default new UserRouter().router;