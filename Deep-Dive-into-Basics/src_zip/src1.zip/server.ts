import express = require("express");
import * as mongoose from 'mongoose';
import { getEnvirmentVariables } from './environments/env';
import UserRouter from "./router/UserRouter";


export class Server {
    public app: express.Application = express();

    constructor()
    {
        this.setConfigurations();
        this.setRoutes();
        this.error404Handler();
        this.handleErrors();
    }

    setConfigurations()
    {
        this.connectMongodb();
    }

    connectMongodb()
    {
        // Connect to databse
        const databaseUrl = getEnvirmentVariables().db_url;
        mongoose.connect(databaseUrl, {useNewUrlParser: true, useUnifiedTopology: true})
            .then(()=>{
                console.log(('mongodb is connected'))
            })
    }

    setRoutes()
    {
        this.app.use('/api/user', UserRouter)
     
    }

    error404Handler()
    {
        this.app.use((req,res)=>{
            res.status(404).json({
                message:"Nof found",
                status_code: 404
            })
        })
    }

    handleErrors()
    {
        this.app.use((error, req,res, next)=>{
            const errorStatus = req.errorStatus || 500;
            res.status(errorStatus).json({
                message: error.message || 'Something went wrong. Please try again.',
                status_code: errorStatus
            })
        })
    }


}