export class UserController{
    static login(req, res, next)
    {
        // res.send('We are here to login')
        const error = new Error('User does not exist')
       // next(error)
        next()

    }

    static test(req, res)
    {
        res.send('We are here to login')
    }
}