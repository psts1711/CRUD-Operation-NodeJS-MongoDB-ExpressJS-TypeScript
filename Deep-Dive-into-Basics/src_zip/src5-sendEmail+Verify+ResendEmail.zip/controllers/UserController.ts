import User from "../models/User";
import { validationResult } from "express-validator";
import {Utils} from "../Utils/Utils";
import {NodeMailer} from "../Utils/NodeMailer";

export class UserController{

    static async signUp(req, res, next)
    {
       //  console.log(Utils.generateVerificationToken());


        const email = req.body.email;
        const password = req.body.password;
        const username = req.body.username;
        const verificationToken = Utils.generateVerificationToken();

        const data = {
            email: email,
            password: password,
            username: username,
            verification_token: verificationToken,
            verification_token_time: Date.now() + new Utils().MAX_TOKEN_TIME,
            created_at: new Date(),
            updated_at: new Date()
        };

        
        try {
            let user = await new User(data).save();

            res.send(user);

            // Send Verification Email

            await NodeMailer.sendEmail({to:['amitkumar.sinha.910@gmail.com'], subject:'Your OTP Key', html:`<h1>Your Verification OTP is: ${verificationToken}</h1>`}).then(()=>{
                console.log('success')
            }).catch(err=>{
                console.log(err)
            })

        }catch (e) {
            next(e)
        }

    }

    static async verifyUserToken(req,res,next)
    {
        const verficationToken = req.body.verification_token;
        const email = req.body.email;

        //console.log(email)

        try {
            const user = await User.findOneAndUpdate({email: email, verification_token: verficationToken,
                verification_token_time:{$gt: Date.now()}
            }, {verified: true, updated_at: new Date()}, {new: true});

            console.log(user)

            if(user) {
                res.send(user);
            }else {
                throw new Error('Verification token is expired. Please request for a new one.')
            }

        }catch (e) {
            next(e)
        }
    }

    static async resendVerificationEmail(req,res,next){

        const email = req.query.email;
        const verificationToken = Utils.generateVerificationToken();


        try{
           const user : any = await User.findOneAndUpdate({email: email}, {
                verification_token: verificationToken,
                verification_token_time : Date.now() + new Utils().MAX_TOKEN_TIME,
            });

           if(user){

               await NodeMailer.sendEmail({to:[user.email], subject:'Your New OTP Key', html:`<h1>Your Verification OTP is: ${verificationToken}</h1>`}).then(()=>{
                   console.log('success')
               }).catch(err=>{
                   console.log(err)
               })

               res.json({
                   success: true
               });

           }else{
               throw Error('User does not exit')
           }

        }catch (e) {
            next(e)
        }
    }

    static login(req, res, next)
    {
        // res.send('We are here to login')
        
       // res.send(req.query)         // for param 1st
       // res.send(req.body)          // 2nd
       
      /*  const email = req.body.email;
       const password = req.body.password;
       const user = new User({email: email, password: password});
       user.save().then((user)=>{
           res.send(user)
       }).catch((err)=>{
           next(err)
       }) */

    /*    const error = validationResult(req)
       const username = req.body.username;
       const email = req.body.email;
       const password = req.body.password;

       if(!error.isEmpty())
       {
           const errorMsg  = new Error(error.array()[0].msg)
          next(errorMsg)
       } */


    }

   
}