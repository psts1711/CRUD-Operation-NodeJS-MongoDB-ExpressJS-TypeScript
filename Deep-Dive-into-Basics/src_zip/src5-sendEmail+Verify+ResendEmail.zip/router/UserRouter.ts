import { Router } from "express";
import { UserController } from "../controllers/UserController";
import {body} from 'express-validator'
import { UserValidator } from "../validators/UserValidators";
import {GlobalMiddleware} from "../middleware/GlobalMiddleware";

 class UserRouter{
    public router: Router;

    constructor() {
        this.router = Router();
        this.getRoutes();
        this.postRoutes();
        this.patchRoutes();
        this.deleteRoute();

    }
    
    getRoutes()
    {
        //this.router.get('/login',UserController.login)
        // this.router.post('/login',UserValidator.login(),UserController.login)
        // console.log('route log');

        this.router.get('/emailresend', UserController.resendVerificationEmail)


    }

    postRoutes()
    {
        this.router.post('/signup',UserValidator.signUp(), GlobalMiddleware.checkError, UserController.signUp);

    }

    patchRoutes()
    {
        this.router.patch('/verify', UserValidator.verifyUser(), GlobalMiddleware.checkError, UserController.verifyUserToken)
    }

    deleteRoute()
    {

    }
}

export default new UserRouter().router;