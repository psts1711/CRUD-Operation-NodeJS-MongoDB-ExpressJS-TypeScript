import {body, query} from "express-validator";
import User from "../models/User";
import {NodeMailer} from "../Utils/NodeMailer";

export class UserValidator{

    static signUp(){
       return [

           // Email Validation
           body('email', 'Email is required').isEmail().custom((email,{req})=>{
               console.log(req.body)
               return User.findOne({email:email}).then(user=>{
                   if(user)
                   {

                       throw new Error('User Already Exist')
                   }
                   else
                   {
                       return true;
                   }
               })
           }),

           // Password Validation
           body('password', 'Password is required')
               .isAlphanumeric().isLength({min: 8, max:20})
               .withMessage('Password can be from 8-20 character'),

           // Username Validation
           body('username', 'Username is required').isString()

       ];
    }

    static verifyUser()
    {
        return [
            body('email', 'Email is required').isEmail(),
            body('verification_token', 'Verification token is required').isNumeric()

        ]
    }

    static resendVerificationEmail(){
        return [query('email', 'Email is required').isEmail()]
    }
}