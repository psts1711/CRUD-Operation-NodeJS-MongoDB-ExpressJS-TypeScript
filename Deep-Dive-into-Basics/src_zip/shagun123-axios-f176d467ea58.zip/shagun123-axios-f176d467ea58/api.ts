import {Http} from "./http.js";

export class Api {
    static getUsers(){
       return  Http.get('users')
    }
}
