import {Api} from './api.js'

Api.getUsers().then(data=>{
    console.log(data);
}).catch(er=>{
    console.log(er);
})

// demo -> api -> http -> axios
