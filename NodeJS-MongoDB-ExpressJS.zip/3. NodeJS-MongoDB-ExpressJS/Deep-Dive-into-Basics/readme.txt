npm install -g typescript ts-node

npm install typescript ts-node express node @types/express @types/node nodemon @types/nodemon

npm install mongoose @types/mongoose

npm install body-parser @types/body-parser

// sendgrid mailer is using
npm i @types/nodemailer nodemailer nodemailer-sendgrid-transport --save

npm i @types/bcrypt bcrypt --save


npm i @types/jsonwebtoken jsonwebtoken --save

npm i jsonwebtoken

npm i multer @types/multer --save

npm i node-schedule @types/node-schedule --save

npm i loadtest

npm i exceljs @types/exceljs

npm i passport @types/passport
npm i passport-facebook @types/passport-facebook

// aws
"start": "NODE_ENV=production node dist/index.js"      // for aws
create ne file .npmrc
create ebextension folder => create 01_nginx.config

